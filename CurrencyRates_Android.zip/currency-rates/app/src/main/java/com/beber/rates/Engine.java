package com.beber.rates;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/**
 * כל הלוגיקה של התוכנה המקורית: הורדת שערים, היסטוריה, בדיקת התראות, יומן והודעות.
 * משותף למסך האפליקציה ולבדיקה ברקע.
 */
public final class Engine {

    public static final String[] CODES = {"USD", "EUR", "GBP", "CHF", "CAD", "AUD", "RUB"};
    public static final String[] NAMES = {"דולר אמריקאי", "אירו", "לירה שטרלינג", "פרנק שוויצרי",
            "דולר קנדי", "דולר אוסטרלי", "רובל רוסי"};
    public static final String[] COUNTRIES = {"ארצות הברית", "האיחוד האירופי", "בריטניה", "שוויץ",
            "קנדה", "אוסטרליה", "רוסיה"};

    static final String BOI_URL = "https://boi.org.il/PublicApi/GetExchangeRates";
    static final int TIMEOUT_MS = 20000;
    static final int LOG_LIMIT = 500;
    static final int HISTORY_DAYS = 14;
    static final String FILE_NAME = "currency_alerts.json";
    static final int JOB_ID = 4711;
    static final String CH_SOUND = "rate_alerts_sound";
    static final String CH_QUIET = "rate_alerts_quiet";

    static final Object LOCK = new Object();

    private Engine() {
    }

    // ============================================================
    // עזרים
    // ============================================================
    static int indexOf(String code) {
        for (int i = 0; i < CODES.length; i++) {
            if (CODES[i].equals(code)) return i;
        }
        return -1;
    }

    static String name(String code) {
        int i = indexOf(code);
        return (i >= 0 ? NAMES[i] : code) + " (" + code + ")";
    }

    static Double num(JSONObject o, String key) {
        if (o == null) return null;
        Object v = o.opt(key);
        if (v instanceof Number) {
            double d = ((Number) v).doubleValue();
            return (Double.isNaN(d) || Double.isInfinite(d)) ? null : d;
        }
        if (v instanceof String) {
            try {
                return Double.parseDouble(((String) v).trim());
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }

    static String str(JSONObject o, String key) {
        if (o == null) return "";
        Object v = o.opt(key);
        if (v == null || v == JSONObject.NULL) return "";
        return String.valueOf(v);
    }

    static String first10(String s) {
        return s.length() > 10 ? s.substring(0, 10) : s;
    }

    static JSONObject obj(JSONObject parent, String key) throws JSONException {
        JSONObject o = parent.optJSONObject(key);
        if (o == null) {
            o = new JSONObject();
            parent.put(key, o);
        }
        return o;
    }

    static Object orNull(Double d) {
        return d == null ? JSONObject.NULL : (Object) d;
    }

    static String fmtRate(Double v) {
        if (v == null) return "—";
        return String.format(Locale.US, v >= 0.1 ? "%.4f" : "%.5f", v);
    }

    static String fmtG(double v) {
        DecimalFormat f = new DecimalFormat("0.######", DecimalFormatSymbols.getInstance(Locale.US));
        return f.format(v);
    }

    static String arrow(Double v) {
        if (v == null) return "";
        return v > 0.005 ? "▲" : (v < -0.005 ? "▼" : "•");
    }

    static String now() {
        return new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US).format(new Date());
    }

    // ============================================================
    // שמירה וטעינה
    // ============================================================
    static File file(Context ctx) {
        return new File(ctx.getFilesDir(), FILE_NAME);
    }

    public static JSONObject load(Context ctx) {
        JSONObject st;
        try {
            File f = file(ctx);
            if (f.exists()) {
                byte[] buf;
                try (FileInputStream in = new FileInputStream(f)) {
                    buf = readAll(in);
                }
                st = new JSONObject(new String(buf, StandardCharsets.UTF_8));
            } else {
                st = new JSONObject();
            }
        } catch (Exception e) {
            st = new JSONObject();
        }
        try {
            for (String k : new String[]{"alerts", "history", "active", "boi", "live"}) obj(st, k);
            JSONObject opt = obj(st, "options");
            if (!opt.has("notify_back")) opt.put("notify_back", true);
            if (!opt.has("popup")) opt.put("popup", true);
            if (!opt.has("toast")) opt.put("toast", true);
            if (!opt.has("sound")) opt.put("sound", true);
            if (!opt.has("background")) opt.put("background", true);
            if (!opt.has("bg_minutes")) opt.put("bg_minutes", 15);
            if (st.optJSONArray("log") == null) st.put("log", new JSONArray());
            if (st.optJSONArray("popup_queue") == null) st.put("popup_queue", new JSONArray());
            if (st.optJSONArray("errors") == null) st.put("errors", new JSONArray());
            if (!st.has("unread")) st.put("unread", 0);
        } catch (JSONException ignored) {
        }
        return st;
    }

    public static void save(Context ctx, JSONObject st) {
        File f = file(ctx);
        File tmp = new File(f.getPath() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(st.toString().getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        } catch (IOException e) {
            return;
        }
        if (!tmp.renameTo(f)) {
            f.delete();
            tmp.renameTo(f);
        }
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        return bo.toByteArray();
    }

    // ============================================================
    // רשת
    // ============================================================
    static String httpGet(String url) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(TIMEOUT_MS);
        c.setReadTimeout(TIMEOUT_MS);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 CurrencyRatesApp/4.0 (Android)");
        c.setRequestProperty("Accept", "application/json");
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            try (InputStream in = c.getInputStream()) {
                return new String(readAll(in), StandardCharsets.UTF_8);
            }
        } finally {
            c.disconnect();
        }
    }

    static JSONObject getBoi() throws Exception {
        Object data = new JSONTokener(httpGet(BOI_URL)).nextValue();
        JSONArray rows = null;
        if (data instanceof JSONObject) rows = ((JSONObject) data).optJSONArray("exchangeRates");
        else if (data instanceof JSONArray) rows = (JSONArray) data;
        JSONObject res = new JSONObject();
        if (rows == null) return res;
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            String code = (row.has("key") ? str(row, "key") : str(row, "currency")).toUpperCase(Locale.US).trim();
            if (indexOf(code) < 0) continue;
            Double value = num(row, "currentExchangeRate");
            if (value == null) value = num(row, "rate");
            if (value == null) continue;
            Double unit = num(row, "unit");
            double u = (unit == null || unit == 0) ? 1.0 : unit;
            JSONObject o = new JSONObject();
            o.put("rate", value / u);
            o.put("updated", str(row, "lastUpdate"));
            o.put("change", orNull(num(row, "currentChange")));
            res.put(code, o);
        }
        return res;
    }

    /** ממיר '1 ש"ח = X מטבע' ל-'1 מטבע = Y ש"ח'. */
    static JSONObject invert(JSONObject rates, boolean lower) throws JSONException {
        JSONObject out = new JSONObject();
        if (rates == null) return out;
        for (String code : CODES) {
            Double raw = num(rates, lower ? code.toLowerCase(Locale.US) : code);
            if (raw != null && raw > 0) out.put(code, 1.0 / raw);
        }
        return out;
    }

    /** מחזיר [שערים, תאריך] לפי סוג המקור. */
    static Object[] parseLive(int kind, JSONObject data) throws Exception {
        if (kind == 0) { // Frankfurter / ECB
            return new Object[]{invert(data.optJSONObject("rates"), false), str(data, "date")};
        }
        if (kind == 1) { // open.er-api.com
            if (!"success".equals(str(data, "result"))) throw new IOException("תשובה לא תקינה");
            String date = "";
            Double ts = num(data, "time_last_update_unix");
            if (ts != null) {
                date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date((long) (ts * 1000)));
            }
            return new Object[]{invert(data.optJSONObject("rates"), false), date};
        }
        // fawazahmed0 currency-api
        return new Object[]{invert(data.optJSONObject("ils"), true), str(data, "date")};
    }

    // מקורות לשער הרציף לפי סדר עדיפות. מטבע שחסר במקור אחד נלקח מהבא.
    static final String[][] LIVE_SOURCES = {
            {"ECB", "https://api.frankfurter.dev/v1/latest?base=ILS", "0"},
            {"ECB", "https://api.frankfurter.app/latest?from=ILS", "0"},
            {"ER-API", "https://open.er-api.com/v6/latest/ILS", "1"},
            {"CurrencyAPI", "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/ils.json", "2"},
            {"CurrencyAPI", "https://latest.currency-api.pages.dev/v1/currencies/ils.json", "2"},
    };

    static JSONObject fetchAll() {
        JSONObject out = new JSONObject();
        JSONArray errors = new JSONArray();
        JSONObject boi = new JSONObject();
        JSONObject live = new JSONObject();
        try {
            boi = getBoi();
        } catch (Exception e) {
            errors.put("בנק ישראל: " + e.getMessage());
        }
        List<String> liveErrors = new ArrayList<>();
        for (String[] src : LIVE_SOURCES) {
            List<String> missing = new ArrayList<>();
            for (String c : CODES) if (!live.has(c)) missing.add(c);
            if (missing.isEmpty()) break;
            try {
                JSONObject data = new JSONObject(httpGet(src[1]));
                Object[] parsed = parseLive(Integer.parseInt(src[2]), data);
                JSONObject rates = (JSONObject) parsed[0];
                for (String code : missing) {
                    Double r = num(rates, code);
                    if (r != null) {
                        JSONObject o = new JSONObject();
                        o.put("rate", r);
                        o.put("date", parsed[1]);
                        o.put("source", src[0]);
                        live.put(code, o);
                    }
                }
            } catch (Exception e) {
                liveErrors.add(src[0] + ": " + e.getMessage());
            }
        }
        boolean allLive = true;
        for (String c : CODES) if (!live.has(c)) allLive = false;
        if (!allLive) for (String e : liveErrors) errors.put(e);
        try {
            out.put("boi", boi);
            out.put("live", live);
            out.put("errors", errors);
        } catch (JSONException ignored) {
        }
        return out;
    }

    // ============================================================
    // חישובים
    // ============================================================
    static Double official(JSONObject st, String code) {
        return num(st.optJSONObject("boi").optJSONObject(code), "rate");
    }

    static Double liveRate(JSONObject st, String code) {
        return num(st.optJSONObject("live").optJSONObject(code), "rate");
    }

    static Double calcDiff(JSONObject st, String code) {
        Double o = official(st, code), l = liveRate(st, code);
        if (o == null || o == 0 || l == null) return null;
        return (l / o - 1) * 100;
    }

    static Double previousRate(JSONObject st, String code, String source, String date) {
        if (date == null || date.isEmpty()) return null;
        JSONObject h = st.optJSONObject("history").optJSONObject(code);
        JSONObject days = h == null ? null : h.optJSONObject(source);
        if (days == null) return null;
        String best = null;
        Iterator<String> it = days.keys();
        while (it.hasNext()) {
            String d = it.next();
            if (d.compareTo(date) < 0 && (best == null || d.compareTo(best) > 0)) best = d;
        }
        return best == null ? null : num(days, best);
    }

    static Double dailyChange(JSONObject st, String code, String source) {
        JSONObject boi = st.optJSONObject("boi").optJSONObject(code);
        Double current, prev;
        if ("boi".equals(source)) {
            if (boi == null) return null;
            Double ch = num(boi, "change");
            if (ch != null) return ch;
            current = num(boi, "rate");
            prev = previousRate(st, code, "boi", first10(str(boi, "updated")));
        } else {
            JSONObject live = st.optJSONObject("live").optJSONObject(code);
            if (live == null) return null;
            current = num(live, "rate");
            prev = previousRate(st, code, "live", first10(str(live, "date")));
            if (prev == null && boi != null) {
                Double ch = num(boi, "change");
                Double br = num(boi, "rate");
                if (ch != null && ch != -100 && br != null) prev = br / (1 + ch / 100);
            }
        }
        if (prev == null || prev == 0 || current == null) return null;
        return (current / prev - 1) * 100;
    }

    static Double displayChange(JSONObject st, String code) {
        Double c = dailyChange(st, code, "boi");
        return c != null ? c : dailyChange(st, code, "live");
    }

    static void recordHistory(JSONObject st, JSONObject boi, JSONObject live) throws JSONException {
        JSONObject hist = st.optJSONObject("history");
        for (String code : CODES) {
            JSONObject b = boi.optJSONObject(code);
            if (b != null) {
                String d = first10(str(b, "updated"));
                Double r = num(b, "rate");
                if (!d.isEmpty() && r != null) obj(obj(hist, code), "boi").put(d, r);
            }
            JSONObject l = live.optJSONObject(code);
            if (l != null) {
                String d = first10(str(l, "date"));
                Double r = num(l, "rate");
                if (!d.isEmpty() && r != null) obj(obj(hist, code), "live").put(d, r);
            }
        }
        Iterator<String> codes = hist.keys();
        while (codes.hasNext()) {
            JSONObject sources = hist.optJSONObject(codes.next());
            if (sources == null) continue;
            Iterator<String> srcs = sources.keys();
            while (srcs.hasNext()) {
                JSONObject days = sources.optJSONObject(srcs.next());
                if (days == null) continue;
                List<String> keys = new ArrayList<>();
                Iterator<String> dk = days.keys();
                while (dk.hasNext()) keys.add(dk.next());
                Collections.sort(keys);
                for (int i = 0; i < keys.size() - HISTORY_DAYS; i++) days.remove(keys.get(i));
            }
        }
    }

    // ============================================================
    // התראות
    // ============================================================
    static String[][] sourcesFor(String source) {
        if ("boi".equals(source)) return new String[][]{{"שער יציג", "boi"}};
        if ("live".equals(source)) return new String[][]{{"שער רציף", "live"}};
        return new String[][]{{"שער יציג", "boi"}, {"שער רציף", "live"}};
    }

    static JSONArray detail(String label, double value, double th) throws JSONException {
        JSONArray a = new JSONArray();
        a.put(label);
        a.put(value);
        a.put(th);
        return a;
    }

    /** מחזיר null אם אין נתונים, אחרת {סוג: [תווית, ערך, סף]}. */
    static JSONObject evaluate(JSONObject st, String code, JSONObject cfg) throws JSONException {
        JSONObject found = new JSONObject();
        boolean hasData = false;
        String source = str(cfg, "source");
        Double high = num(cfg, "high"), low = num(cfg, "low"), pct = num(cfg, "pct"), gap = num(cfg, "gap");

        for (String[] s : sourcesFor(source)) {
            Double value = "boi".equals(s[1]) ? official(st, code) : liveRate(st, code);
            if (value == null) continue;
            hasData = true;
            if (high != null && value > high && !found.has("high")) found.put("high", detail(s[0], value, high));
            if (low != null && value < low && !found.has("low")) found.put("low", detail(s[0], value, low));
        }
        if (pct != null && pct > 0) {
            for (String[] s : sourcesFor(source)) {
                Double ch = dailyChange(st, code, s[1]);
                if (ch != null && Math.abs(ch) >= pct) {
                    found.put("pct", detail(s[0], ch, pct));
                    break;
                }
            }
        }
        if (gap != null && gap > 0) {
            Double diff = calcDiff(st, code);
            if (diff != null) {
                hasData = true;
                if (Math.abs(diff) >= gap) found.put("gap", detail("פער", diff, gap));
            }
        }
        return hasData ? found : null;
    }

    static String describe(JSONObject st, String code, String kind, JSONArray d, boolean started) {
        String name = name(code);
        JSONObject cfg = st.optJSONObject("alerts").optJSONObject(code);
        if (started && d != null) {
            String label = d.optString(0);
            double value = d.optDouble(1), th = d.optDouble(2);
            switch (kind) {
                case "high":
                    return "▲ " + name + ": " + label + " " + fmtRate(value) + " — עבר מעל " + fmtRate(th);
                case "low":
                    return "▼ " + name + ": " + label + " " + fmtRate(value) + " — ירד מתחת ל-" + fmtRate(th);
                case "pct":
                    return arrow(value) + " " + name + ": שינוי יומי " + String.format(Locale.US, "%+.2f", value)
                            + "% ב" + label + " — מעבר ל-±" + fmtG(th) + "%";
                default:
                    return "⇄ " + name + ": פער יציג/רציף " + String.format(Locale.US, "%+.2f", value)
                            + "% — מעבר ל-±" + fmtG(th) + "%";
            }
        }
        switch (kind) {
            case "high":
                return "✓ " + name + ": חזר אל מתחת ל-" + fmtRate(num(cfg, "high"));
            case "low":
                return "✓ " + name + ": חזר אל מעל " + fmtRate(num(cfg, "low"));
            case "pct":
                return "✓ " + name + ": השינוי היומי חזר לטווח";
            default:
                return "✓ " + name + ": הפער בין היציג לרציף חזר לטווח";
        }
    }

    static List<JSONObject> checkAlerts(JSONObject st) throws JSONException {
        List<JSONObject> events = new ArrayList<>();
        JSONObject alerts = st.optJSONObject("alerts");
        JSONObject active = st.optJSONObject("active");
        for (String code : CODES) {
            JSONObject cfg = alerts.optJSONObject(code);
            if (cfg == null || !cfg.optBoolean("enabled", true)) {
                active.put(code, new JSONObject());
                continue;
            }
            JSONObject found = evaluate(st, code, cfg);
            if (found == null) continue; // אין נתון - משאירים את המצב הקודם
            JSONObject previous = active.optJSONObject(code);
            if (previous == null) previous = new JSONObject();
            Iterator<String> it = found.keys();
            while (it.hasNext()) {
                String kind = it.next();
                if (!previous.has(kind)) {
                    events.add(event(code, kind, true, describe(st, code, kind, found.optJSONArray(kind), true)));
                }
            }
            it = previous.keys();
            while (it.hasNext()) {
                String kind = it.next();
                if (!found.has(kind)) {
                    events.add(event(code, kind, false, describe(st, code, kind, null, false)));
                }
            }
            active.put(code, found);
        }
        return events;
    }

    static JSONObject event(String code, String kind, boolean start, String text) throws JSONException {
        JSONObject e = new JSONObject();
        e.put("code", code);
        e.put("kind", kind);
        e.put("start", start);
        e.put("text", text);
        return e;
    }

    static void notifyEvents(Context ctx, JSONObject st, List<JSONObject> events) throws JSONException {
        if (events.isEmpty()) return;
        String when = now();
        JSONArray log = st.optJSONArray("log");
        for (JSONObject e : events) {
            JSONObject entry = new JSONObject(e.toString());
            entry.put("time", when);
            log.put(entry);
        }
        if (log.length() > LOG_LIMIT) {
            JSONArray trimmed = new JSONArray();
            for (int i = log.length() - LOG_LIMIT; i < log.length(); i++) trimmed.put(log.get(i));
            st.put("log", trimmed);
        }
        st.put("unread", st.optInt("unread", 0) + events.size());

        JSONObject opt = st.optJSONObject("options");
        List<JSONObject> shown = new ArrayList<>();
        for (JSONObject e : events) {
            if (e.optBoolean("start") || opt.optBoolean("notify_back", true)) shown.add(e);
        }
        if (shown.isEmpty()) return;
        boolean anyStart = false;
        for (JSONObject e : shown) if (e.optBoolean("start")) anyStart = true;

        if (opt.optBoolean("popup", true)) {
            JSONArray q = st.optJSONArray("popup_queue");
            for (JSONObject e : shown) {
                JSONObject p = new JSONObject(e.toString());
                p.put("time", when);
                q.put(p);
            }
            while (q.length() > 40) q.remove(0);
        }
        if (opt.optBoolean("toast", true)) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < shown.size() && i < 6; i++) {
                if (i > 0) sb.append('\n');
                sb.append(shown.get(i).optString("text"));
            }
            postNotification(ctx, anyStart ? "התראת שער מטבע" : "שער חזר לטווח", sb.toString(),
                    opt.optBoolean("sound", true));
        }
    }

    // ============================================================
    // הודעות מערכת
    // ============================================================
    public static void ensureChannels(Context ctx) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel loud = new NotificationChannel(CH_SOUND, "התראות שער (עם צליל)",
                NotificationManager.IMPORTANCE_HIGH);
        loud.setDescription("חריגה מהספים שהגדרת");
        loud.enableVibration(true);
        nm.createNotificationChannel(loud);
        NotificationChannel quiet = new NotificationChannel(CH_QUIET, "התראות שער (שקט)",
                NotificationManager.IMPORTANCE_HIGH);
        quiet.setSound(null, null);
        quiet.enableVibration(false);
        nm.createNotificationChannel(quiet);
    }

    public static boolean canNotify(Context ctx) {
        if (Build.VERSION.SDK_INT >= 33
                && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm != null && nm.areNotificationsEnabled();
    }

    static void postNotification(Context ctx, String title, String text, boolean sound) {
        if (!canNotify(ctx)) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        ensureChannels(ctx);
        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(ctx, sound ? CH_SOUND : CH_QUIET)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setColor(0xFFE8590C)
                .build();
        nm.notify((int) (System.currentTimeMillis() % 1000000), n);
    }

    // ============================================================
    // בדיקה ברקע (JobScheduler - פעם ב-15 דקות לפחות, גם כשהאפליקציה סגורה)
    // ============================================================
    public static void applySchedule(Context ctx) {
        JSONObject opt;
        synchronized (LOCK) {
            opt = load(ctx).optJSONObject("options");
        }
        JobScheduler js = (JobScheduler) ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        if (!opt.optBoolean("background", true)) {
            js.cancel(JOB_ID);
            return;
        }
        int minutes = Math.max(15, opt.optInt("bg_minutes", 15));
        long period = minutes * 60L * 1000L;
        JobInfo existing = js.getPendingJob(JOB_ID);
        if (existing != null && existing.getIntervalMillis() == period) return;
        JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(ctx, RateJob.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(period)
                .build();
        js.schedule(job);
    }

    // ============================================================
    // רענון מלא: הורדה + היסטוריה + התראות + שמירה
    // ============================================================
    public static JSONObject refresh(Context ctx, boolean background) {
        JSONObject data = fetchAll(); // מחוץ לנעילה - הרשת איטית
        synchronized (LOCK) {
            JSONObject st = load(ctx);
            try {
                JSONObject boi = data.optJSONObject("boi");
                JSONObject live = data.optJSONObject("live");
                if (boi.length() > 0) st.put("boi", boi);
                JSONObject cur = st.optJSONObject("live");
                Iterator<String> it = live.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    cur.put(k, live.get(k));
                }
                recordHistory(st, boi, live);
                JSONArray errors = data.optJSONArray("errors");
                boolean gotAny = boi.length() > 0 || live.length() > 0;
                if (gotAny) st.put("last_refresh", now());
                st.put("errors", errors);
                if (errors.length() == 0) {
                    st.put("status", "הנתונים עודכנו בהצלחה");
                    st.put("status_kind", "ok");
                } else if (gotAny) {
                    st.put("status", "חלק מהנתונים לא עודכנו - מוצגים הנתונים האחרונים שהתקבלו");
                    st.put("status_kind", "busy");
                } else {
                    st.put("status", "לא ניתן לעדכן כרגע - ננסה שוב ברענון הבא");
                    st.put("status_kind", "error");
                }
                st.put("last_source", background ? "רקע" : "אפליקציה");
                notifyEvents(ctx, st, checkAlerts(st));
            } catch (JSONException ignored) {
            }
            save(ctx, st);
            return st;
        }
    }

    /** שמירת כל ההתראות והאפשרויות מחלון ההגדרות. */
    public static JSONObject saveSettings(Context ctx, JSONObject alertsIn, JSONObject optionsIn) {
        synchronized (LOCK) {
            JSONObject st = load(ctx);
            try {
                JSONObject old = st.optJSONObject("alerts");
                JSONObject active = st.optJSONObject("active");
                JSONObject clean = new JSONObject();
                for (String code : CODES) {
                    JSONObject a = alertsIn.optJSONObject(code);
                    if (a != null) {
                        JSONObject c = new JSONObject();
                        boolean any = false;
                        for (String k : new String[]{"low", "high", "pct", "gap"}) {
                            Double v = num(a, k);
                            if (v != null && v > 0) {
                                c.put(k, v);
                                any = true;
                            } else {
                                c.put(k, JSONObject.NULL);
                            }
                        }
                        String src = str(a, "source");
                        c.put("source", ("boi".equals(src) || "live".equals(src)) ? src : "any");
                        c.put("enabled", a.optBoolean("enabled", true));
                        if (any) clean.put(code, c);
                    }
                    JSONObject before = old.optJSONObject(code);
                    JSONObject after = clean.optJSONObject(code);
                    String b = before == null ? "" : before.toString();
                    String n = after == null ? "" : after.toString();
                    if (!b.equals(n)) active.remove(code); // בדיקה מחדש מיידית לפי ההגדרה החדשה
                }
                st.put("alerts", clean);
                JSONObject opt = st.optJSONObject("options");
                for (String k : new String[]{"notify_back", "popup", "toast", "sound", "background"}) {
                    if (optionsIn.has(k)) opt.put(k, optionsIn.optBoolean(k));
                }
                if (optionsIn.has("bg_minutes")) opt.put("bg_minutes", Math.max(15, optionsIn.optInt("bg_minutes", 15)));
                notifyEvents(ctx, st, checkAlerts(st));
                st.put("status", "ההגדרות נשמרו • " + clean.length() + " מטבעות עם התראה");
                st.put("status_kind", "ok");
            } catch (JSONException ignored) {
            }
            save(ctx, st);
        }
        applySchedule(ctx);
        return uiState(ctx);
    }

    public static void testAlert(Context ctx, JSONObject optionsIn) {
        synchronized (LOCK) {
            JSONObject st = load(ctx);
            try {
                JSONObject backup = new JSONObject(st.optJSONObject("options").toString());
                JSONObject opt = st.optJSONObject("options");
                for (String k : new String[]{"notify_back", "popup", "toast", "sound"}) {
                    if (optionsIn.has(k)) opt.put(k, optionsIn.optBoolean(k));
                }
                List<JSONObject> ev = new ArrayList<>();
                ev.add(event("USD", "test", true, "🧪 בדיקה: כך תיראה התראה על חריגה"));
                notifyEvents(ctx, st, ev);
                st.put("options", backup);
            } catch (JSONException ignored) {
            }
            save(ctx, st);
        }
    }

    public static void mutate(Context ctx, String what) {
        synchronized (LOCK) {
            JSONObject st = load(ctx);
            try {
                if ("clear_log".equals(what)) {
                    st.put("log", new JSONArray());
                    st.put("unread", 0);
                } else if ("mark_read".equals(what)) {
                    st.put("unread", 0);
                } else if ("ack_popup".equals(what)) {
                    st.put("popup_queue", new JSONArray());
                }
            } catch (JSONException ignored) {
            }
            save(ctx, st);
        }
    }

    public static String logCsv(Context ctx) {
        JSONArray log;
        synchronized (LOCK) {
            log = load(ctx).optJSONArray("log");
        }
        StringBuilder sb = new StringBuilder("﻿זמן,מטבע,סוג,אירוע\n");
        for (int i = 0; i < log.length(); i++) {
            JSONObject e = log.optJSONObject(i);
            if (e == null) continue;
            sb.append(csv(str(e, "time"))).append(',').append(csv(str(e, "code"))).append(',')
                    .append(e.optBoolean("start") ? "חריגה" : "חזרה לטווח").append(',')
                    .append(csv(str(e, "text"))).append('\n');
        }
        return sb.toString();
    }

    static String csv(String s) {
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    /** המצב המלא למסך, כולל ערכים מחושבים לכל מטבע. */
    public static JSONObject uiState(Context ctx) {
        synchronized (LOCK) {
            JSONObject st = load(ctx);
            try {
                JSONArray rows = new JSONArray();
                for (int i = 0; i < CODES.length; i++) {
                    String code = CODES[i];
                    JSONObject r = new JSONObject();
                    r.put("code", code);
                    r.put("name", NAMES[i]);
                    r.put("country", COUNTRIES[i]);
                    r.put("official", orNull(official(st, code)));
                    r.put("live", orNull(liveRate(st, code)));
                    r.put("change", orNull(displayChange(st, code)));
                    r.put("diff", orNull(calcDiff(st, code)));
                    JSONObject b = st.optJSONObject("boi").optJSONObject(code);
                    JSONObject l = st.optJSONObject("live").optJSONObject(code);
                    r.put("boi_updated", b == null ? "" : str(b, "updated"));
                    r.put("live_date", l == null ? "" : str(l, "date"));
                    r.put("live_source", l == null ? "" : str(l, "source"));
                    JSONObject act = st.optJSONObject("active").optJSONObject(code);
                    r.put("active", act == null ? new JSONObject() : act);
                    rows.put(r);
                }
                st.put("rows", rows);
                st.put("has_boi", st.optJSONObject("boi").length() > 0);
                st.put("notif_ok", canNotify(ctx));
                st.remove("history");
            } catch (JSONException ignored) {
            }
            return st;
        }
    }
}

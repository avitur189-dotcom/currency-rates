package com.beber.rates;

import android.app.job.JobParameters;
import android.app.job.JobService;

/** בדיקת שערים ברקע - מופעלת ע"י אנדרואיד גם כשהאפליקציה סגורה. */
public class RateJob extends JobService {

    @Override
    public boolean onStartJob(final JobParameters params) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Engine.refresh(getApplicationContext(), true);
                } catch (Throwable ignored) {
                }
                jobFinished(params, false);
            }
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return true;
    }
}

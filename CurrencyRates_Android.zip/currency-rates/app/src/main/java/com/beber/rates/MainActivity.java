package com.beber.rates;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF0F2F57);
        getWindow().setNavigationBarColor(0xFF0F2F57);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);

        Engine.ensureChannels(this);
        new Thread(new Runnable() {
            @Override
            public void run() {
                Engine.applySchedule(getApplicationContext());
            }
        }).start();

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        js("window.onResumeApp && window.onResumeApp()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        js("window.onPauseApp && window.onPauseApp()");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        js("window.onResumeApp && window.onResumeApp()");
    }

    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript("window.handleBack ? window.handleBack() : false", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    private void js(final String code) {
        if (web == null) return;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript(code, null);
            }
        });
    }

    /** הגשר בין המסך (HTML) לבין הלוגיקה (Java). */
    public class Bridge {

        @JavascriptInterface
        public String getState() {
            return Engine.uiState(getApplicationContext()).toString();
        }

        @JavascriptInterface
        public void refresh(final boolean manual) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Engine.refresh(getApplicationContext(), false);
                    String state = Engine.uiState(getApplicationContext()).toString();
                    js("window.onRefreshed(" + state + ", " + manual + ")");
                }
            }).start();
        }

        @JavascriptInterface
        public String saveSettings(String alertsJson, String optionsJson) {
            try {
                return Engine.saveSettings(getApplicationContext(), new JSONObject(alertsJson),
                        new JSONObject(optionsJson)).toString();
            } catch (Exception e) {
                return Engine.uiState(getApplicationContext()).toString();
            }
        }

        @JavascriptInterface
        public void testAlert(String optionsJson) {
            try {
                Engine.testAlert(getApplicationContext(), new JSONObject(optionsJson));
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void mutate(String what) {
            Engine.mutate(getApplicationContext(), what);
        }

        @JavascriptInterface
        public void shareLog() {
            String csv = Engine.logCsv(getApplicationContext());
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_SUBJECT, "יומן התראות שערי מטבע");
            send.putExtra(Intent.EXTRA_TEXT, csv);
            Intent chooser = Intent.createChooser(send, "שיתוף היומן");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(chooser);
        }

        @JavascriptInterface
        public void openNotificationSettings() {
            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        }

        @JavascriptInterface
        public void openBatterySettings() {
            try {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                Intent i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        }

        @JavascriptInterface
        public String version() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "";
            }
        }
    }
}
